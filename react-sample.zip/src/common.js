const exports = {};
exports.API_URL = "https://masterdata.thaionzon.com/zipcode";
export default exports;
